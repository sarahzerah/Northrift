<div class="header-area">
            <div class="main-header ">
                <div class="header-top top-bg d-none d-lg-block">
                   <div class="container">
                       <div class="col-xl-12">
                        <div class="row d-flex justify-content-between align-items-center">
                            <div class="header-info-left">
                                <ul>     
                                    <li>+254-724-077-237</li>
                                    <li>northriftwomen@gmail.com </li>
                                </ul>
                            </div>
                            <div class="header-info-right">
                                <ul>     
                                   <a href="https://web.facebook.com/NORTHRIFTWOMENINSTEM/" class="btn-floating btn-lg btn-fb" type="button" role="button"><i class="fab fa-facebook-f"></i></a>
                            <!--Twitter-->
                            <a  href="https://twitter.com/northriftwomen" class="btn-floating btn-lg btn-tw" type="button" role="button"><i class="fab fa-twitter"></i></a>
                                </ul>
                            </div>
                       </div>
                       </div>
                   </div>
                </div>
               <div class="header-bottom  header-sticky">
                    <div class="container">
                        <div class="row align-items-center">
                            <!-- Logo -->
                            <div class="col-xl-2 col-lg-1 col-md-1">
                                <div class="logo">
                                <a href="index.html"><img src="assets/img/logo/NR-in-STEM.png" height="50px" width="150px" alt=""></a>
                                </div>
                            </div>
                            <div class="col-xl-8 col-lg-8 col-md-8">
                                <!-- Main-menu -->
                                <div class="main-menu f-right d-none d-lg-block">
                                    <nav>
                                        <ul id="navigation"> 
                                         <li><a href="index.html">Home</a></li>
                                            <!-- <li><a href="about.html">About</a></li> -->
                                            <li><a href="#">Whow we are </a></li>
                                            <li><a href="#">What we do</a></li>
                                            <li><a href="blog.php">Our Stories</a></li>
                                            <li><a href="contact.php">Contact Us</a></li>
                                        </ul>
                                    </nav>
                                </div>
                            </div>             
                            <div class="col-xl-2 col-lg-3 col-md-3">
                                <!-- Header-btn -->
                                <div class="header-btn d-none d-lg-block">
                                    <a href="#" class="get-btn">Donate</a>
                                </div>
                            </div>
                            <!-- Mobile Menu -->
                            <div class="col-12">
                                <div class="mobile_menu d-block d-lg-none"></div>
                            </div>
                        </div>
                    </div>
               </div>
            </div>
       </div>